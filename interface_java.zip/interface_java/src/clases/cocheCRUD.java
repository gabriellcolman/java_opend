package clases;

public interface cocheCRUD {

    void save();
    void findAll();
    void delete();


    }
