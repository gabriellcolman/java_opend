package com.bicoserus;

public class if_else_java {
    public static void main(String[] args) {
        
    }

}
