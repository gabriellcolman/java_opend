package com.bicoserus;

public class PrimerClase {

    public static void main(String[] args){
          //variables mas comunes
          //ejercicio 1

        int number =1;
        String nombre ="gabriel colman";
        long number2 =150;
        boolean verdadero = true;
        double decimal =9.99d;

          //imprimo variables por pantalla

        System.out.println(number);
        System.out.println(nombre);
        System.out.println(number2);
        System.out.println(verdadero);
        System.out.println(decimal);
    }
}
